package com.example

import com.example.data.local.CurriculumDataSource
import com.example.data.model.SubjectType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testCurriculumSubjects() {
        val subjects = CurriculumDataSource.subjects
        assertEquals(4, subjects.size)
        assertTrue(subjects.contains(SubjectType.MATH))
        assertTrue(subjects.contains(SubjectType.PHYSICS))
        assertTrue(subjects.contains(SubjectType.CHEMISTRY))
        assertTrue(subjects.contains(SubjectType.BIOLOGY))
    }

    @Test
    fun testTotalLessonsCount() {
        val lessons = CurriculumDataSource.allLessons
        // Must contain lessons across all 4 subjects
        assertTrue(lessons.size >= 48)
        val mathLessons = lessons.filter { it.subjectId == SubjectType.MATH.id }
        val physicsLessons = lessons.filter { it.subjectId == SubjectType.PHYSICS.id }
        val chemistryLessons = lessons.filter { it.subjectId == SubjectType.CHEMISTRY.id }
        val biologyLessons = lessons.filter { it.subjectId == SubjectType.BIOLOGY.id }

        assertTrue(mathLessons.isNotEmpty())
        assertTrue(physicsLessons.isNotEmpty())
        assertTrue(chemistryLessons.isNotEmpty())
        assertTrue(biologyLessons.isNotEmpty())
    }

    @Test
    fun testQuizQuestionsBank() {
        val questions = CurriculumDataSource.quizQuestions
        assertTrue(questions.isNotEmpty())
        questions.forEach { q ->
            assertNotNull(q.questionText)
            assertTrue(q.options.size == 4)
            assertTrue(q.correctIndex in 0..3)
        }
    }

    @Test
    fun testDefaultExamTargets() {
        val targets = CurriculumDataSource.defaultExamTargets
        assertEquals(2, targets.size)
        assertTrue(targets.any { it.id == "period_1" })
        assertTrue(targets.any { it.id == "period_2" })
    }
}
