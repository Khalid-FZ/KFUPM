package com.example.data.model

import androidx.compose.ui.graphics.Color

enum class SubjectType(
    val id: String,
    val titleAr: String,
    val shortName: String,
    val colorHex: Long,
    val iconName: String
) {
    MATH("math", "الرياضيات", "رياضيات", 0xFF0284C7, "calculate"),
    PHYSICS("physics", "الفيزياء", "فيزياء", 0xFF10B981, "bolt"),
    CHEMISTRY("chemistry", "الكيمياء", "كيمياء", 0xFF8B5CF6, "science"),
    BIOLOGY("biology", "األحياء وعلم البيئة", "أحياء", 0xFFF59E0B, "eco");

    val color: Color get() = Color(colorHex)
}

data class GradeSection(
    val id: String,
    val subjectId: String,
    val titleAr: String,
    val totalLessonsCount: Int
)

data class Lesson(
    val id: String,
    val subjectId: String,
    val gradeSectionId: String,
    val gradeSectionTitle: String,
    val lessonNumber: Int,
    val titleAr: String,
    val description: String,
    val estimatedMinutes: Int = 30
)

data class QuizQuestion(
    val id: String,
    val lessonId: String,
    val subjectId: String,
    val questionText: String,
    val options: List<String>,
    val correctIndex: Int, // 0: أ, 1: ب, 2: ج, 3: د
    val explanation: String,
    val yearTag: String = "2025",
    val sectionType: String = "القسم األول - أسئلة الـ 3 نجوم" // 3 نجوم أو نجمتين أو أسئلة الصور
)
