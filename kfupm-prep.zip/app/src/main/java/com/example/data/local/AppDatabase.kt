package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.ExamTargetEntity
import com.example.data.model.LessonProgressEntity
import com.example.data.model.QuizResultEntity
import com.example.data.model.StudyTaskEntity

@Database(
    entities = [
        LessonProgressEntity::class,
        QuizResultEntity::class,
        StudyTaskEntity::class,
        ExamTargetEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "kfupm_prep_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
