package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ExamTargetEntity
import com.example.data.model.LessonProgressEntity
import com.example.data.model.QuizResultEntity
import com.example.data.model.StudyTaskEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // Lesson progress
    @Query("SELECT * FROM lesson_progress")
    fun getAllLessonProgress(): Flow<List<LessonProgressEntity>>

    @Query("SELECT * FROM lesson_progress WHERE lessonId = :lessonId")
    suspend fun getLessonProgress(lessonId: String): LessonProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateProgress(progress: LessonProgressEntity)

    // Quiz results
    @Query("SELECT * FROM quiz_results ORDER BY timestamp DESC")
    fun getAllQuizResults(): Flow<List<QuizResultEntity>>

    @Query("SELECT * FROM quiz_results WHERE lessonId = :lessonId ORDER BY timestamp DESC")
    fun getQuizResultsForLesson(lessonId: String): Flow<List<QuizResultEntity>>

    @Insert
    suspend fun insertQuizResult(result: QuizResultEntity): Long

    // Study tasks
    @Query("SELECT * FROM study_tasks ORDER BY dayNumber ASC, id ASC")
    fun getAllTasks(): Flow<List<StudyTaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTasks(tasks: List<StudyTaskEntity>)

    @Update
    suspend fun updateTask(task: StudyTaskEntity)

    @Query("UPDATE study_tasks SET isCompleted = :isCompleted WHERE id = :taskId")
    suspend fun setTaskCompleted(taskId: Long, isCompleted: Boolean)

    // Exam targets
    @Query("SELECT * FROM exam_targets")
    fun getAllExamTargets(): Flow<List<ExamTargetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExamTargets(targets: List<ExamTargetEntity>)

    @Query("UPDATE exam_targets SET isSelected = (id = :selectedId)")
    suspend fun selectExamTarget(selectedId: String)
}
