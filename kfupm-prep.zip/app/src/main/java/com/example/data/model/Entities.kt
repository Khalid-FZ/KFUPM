package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lesson_progress")
data class LessonProgressEntity(
    @PrimaryKey val lessonId: String,
    val subjectId: String,
    val isCompleted: Boolean = false,
    val completedAt: Long? = null,
    val notes: String = "",
    val confidence: Int = 0 // 0 to 5 stars
)

@Entity(tableName = "quiz_results")
data class QuizResultEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val lessonId: String,
    val subjectId: String,
    val quizTitle: String,
    val totalQuestions: Int,
    val correctAnswers: Int,
    val scorePercentage: Int,
    val timeTakenSeconds: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "study_tasks")
data class StudyTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dayNumber: Int,
    val title: String,
    val subjectId: String,
    val lessonId: String? = null,
    val isCompleted: Boolean = false,
    val dateLabel: String = ""
)

@Entity(tableName = "exam_targets")
data class ExamTargetEntity(
    @PrimaryKey val id: String,
    val title: String,
    val subtitle: String,
    val targetTimestamp: Long,
    val isSelected: Boolean = false,
    val notes: String = ""
)
