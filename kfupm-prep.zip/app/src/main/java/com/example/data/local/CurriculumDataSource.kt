package com.example.data.local

import com.example.data.model.ExamTargetEntity
import com.example.data.model.GradeSection
import com.example.data.model.Lesson
import com.example.data.model.QuizQuestion
import com.example.data.model.StudyTaskEntity
import com.example.data.model.SubjectType
import java.util.Calendar

object CurriculumDataSource {

    val subjects = listOf(
        SubjectType.MATH,
        SubjectType.PHYSICS,
        SubjectType.CHEMISTRY,
        SubjectType.BIOLOGY
    )

    val gradeSections = listOf(
        // Mathematics
        GradeSection("math_sec1", SubjectType.MATH.id, "رياضيات أولى ثانوي", 8),
        GradeSection("math_sec2", SubjectType.MATH.id, "رياضيات ثاني ثانوي", 13),

        // Physics
        GradeSection("phys_sec1", SubjectType.PHYSICS.id, "فيزياء أولى ثانوي", 7),
        GradeSection("phys_sec2", SubjectType.PHYSICS.id, "فيزياء ثاني ثانوي", 6),

        // Chemistry
        GradeSection("chem_1", SubjectType.CHEMISTRY.id, "كيمياء 1", 5),
        GradeSection("chem_2", SubjectType.CHEMISTRY.id, "كيمياء 2", 8),
        GradeSection("chem_3", SubjectType.CHEMISTRY.id, "كيمياء 3", 6),
        GradeSection("chem_4", SubjectType.CHEMISTRY.id, "كيمياء 4", 7),

        // Biology & Ecology
        GradeSection("bio_1", SubjectType.BIOLOGY.id, "أحياء 1", 8),
        GradeSection("bio_2", SubjectType.BIOLOGY.id, "أحياء 2", 11),
        GradeSection("bio_3", SubjectType.BIOLOGY.id, "أحياء 3", 12),
        GradeSection("bio_4", SubjectType.BIOLOGY.id, "أحياء 4", 9),
        GradeSection("bio_eco", SubjectType.BIOLOGY.id, "علم البيئة", 8)
    )

    val allLessons = listOf(
        // === رياضيات أولى ثانوي (8 دروس) ===
        Lesson("m_1_1", SubjectType.MATH.id, "math_sec1", "رياضيات أولى ثانوي", 1, "التبرير والبرهان", "األنماط، التخمين، المثال المضاد، العبارات الشرطية والمتكافئة منطقياً"),
        Lesson("m_1_2", SubjectType.MATH.id, "math_sec1", "رياضيات أولى ثانوي", 2, "المسلمات والعالقات الهندسية", "تقاطع المستقيمات، مسلمات القياس والعالقات بين الزوايا"),
        Lesson("m_1_3", SubjectType.MATH.id, "math_sec1", "رياضيات أولى ثانوي", 3, "المستقيم", "ميل المستقيم، صيغ المعادالت، التوازي والتعامد، والبعد بين نقطة ومستقيم"),
        Lesson("m_1_4", SubjectType.MATH.id, "math_sec1", "رياضيات أولى ثانوي", 4, "المثلث", "تصنيف المثلثات، الزوايا الداخلية والخارجية، والتطابق"),
        Lesson("m_1_5", SubjectType.MATH.id, "math_sec1", "رياضيات أولى ثانوي", 5, "المضلعات واألشكال الرباعية", "مجموع زوايا المضلع، متوازي األضالع، المستطيل، المعين، والمربع"),
        Lesson("m_1_6", SubjectType.MATH.id, "math_sec1", "رياضيات أولى ثانوي", 6, "التشابه", "المضلعات المتشابهة، ونظريات تناسب المثلثات والمنصفات"),
        Lesson("m_1_7", SubjectType.MATH.id, "math_sec1", "رياضيات أولى ثانوي", 7, "التحويالت الهندسية", "االنعكاس، اإلزاحة (االنسحاب)، الدوران، التماثل والتمدد"),
        Lesson("m_1_8", SubjectType.MATH.id, "math_sec1", "رياضيات أولى ثانوي", 8, "الدائرة", "الزوايا المركزية والمحيطية، أوتار ومماسات الدائرة، ومعادلة الدائرة"),

        // === رياضيات ثاني ثانوي (13 درس) ===
        Lesson("m_2_1", SubjectType.MATH.id, "math_sec2", "رياضيات ثاني ثانوي", 9, "األعداد الحقيقية والدوال", "مجموعات األعداد، خصائص األعداد الحقيقية، وتمييز الدوال"),
        Lesson("m_2_2", SubjectType.MATH.id, "math_sec2", "رياضيات ثاني ثانوي", 10, "دوال خاصة", "الدوال متعددة التعريف، دالة أكبر عدد صحيح، ودالة القيمة المطلقة"),
        Lesson("m_2_3", SubjectType.MATH.id, "math_sec2", "رياضيات ثاني ثانوي", 11, "المتباينات", "حل المتباينات الخطية، أنظمة المتباينات، وتحديد رؤوس منطقة الحل"),
        Lesson("m_2_4", SubjectType.MATH.id, "math_sec2", "رياضيات ثاني ثانوي", 12, "المصفوفات", "رتب المصفوفات، العمليات الحسابية، المحددات، والنظير الضربي"),
        Lesson("m_2_5", SubjectType.MATH.id, "math_sec2", "رياضيات ثاني ثانوي", 13, "األعداد المركبة والمعادلة التربيعية", "قوى i، العمليات على األعداد المركبة، القانون العام والمميز"),
        Lesson("m_2_6", SubjectType.MATH.id, "math_sec2", "رياضيات ثاني ثانوي", 14, "كثيرات الحدود", "درجة كثيرة الحدود، القسمة التركيبية، ونظرية الباقي والعوامل"),
        Lesson("m_2_7", SubjectType.MATH.id, "math_sec2", "رياضيات ثاني ثانوي", 15, "العمليات على الدوال", "جمع وطرح وتركيب الدوال، وتعيين الدالة العكسية"),
        Lesson("m_2_8", SubjectType.MATH.id, "math_sec2", "رياضيات ثاني ثانوي", 16, "الدالة الجذرية", "مجال ومدى الدوال الجذرية، تبسيط الجذور، وحل المعادالت الجذرية"),
        Lesson("m_2_9", SubjectType.MATH.id, "math_sec2", "رياضيات ثاني ثانوي", 17, "العالقات والدوال النسبية", "تبسيط العبارات النسبية، خطوط التقارب، والتغير الطردي والعكسي"),
        Lesson("m_2_10", SubjectType.MATH.id, "math_sec2", "رياضيات ثاني ثانوي", 18, "المتتابعات والمتسلسالت", "المتتابعات الحسابية والهندسية، الحد النوني، والمجموع بالرمز سيجما"),
        Lesson("m_2_11", SubjectType.MATH.id, "math_sec2", "رياضيات ثاني ثانوي", 19, "نظرية ذات الحدين", "مفكوك ذات الحدين، إيجاد حد معين، ومثلث باسكال"),
        Lesson("m_2_12", SubjectType.MATH.id, "math_sec2", "رياضيات ثاني ثانوي", 20, "االحتماالت", "مبدأ العد األساسي، التباديل والتوافيق، واالحتماالت المشروطة"),
        Lesson("m_2_13", SubjectType.MATH.id, "math_sec2", "رياضيات ثاني ثانوي", 21, "حساب المثلثات", "الدوال المثلثية، الزوايا المرجعية، وقوانين الجيوب وجيوب التمام"),

        // === فيزياء أولى ثانوي (7 دروس) ===
        Lesson("p_1_1", SubjectType.PHYSICS.id, "phys_sec1", "فيزياء أولى ثانوي", 1, "أساسيات الفيزياء", "طبيعة العلم، النظام الدولي للوحدات، وتوليد الفرضيات"),
        Lesson("p_1_2", SubjectType.PHYSICS.id, "phys_sec1", "فيزياء أولى ثانوي", 2, "مدخل إلى علم الفيزياء", "الكميات القياسية والمتجهة، الدقة والضبط، والتحليل البعدي"),
        Lesson("p_1_3", SubjectType.PHYSICS.id, "phys_sec1", "فيزياء أولى ثانوي", 3, "اإلزاحة والسرعة والتسارع", "منحنيات الموقع-الزمن، السرعة المتجهة، ومفهوم التسارع"),
        Lesson("p_1_4", SubjectType.PHYSICS.id, "phys_sec1", "فيزياء أولى ثانوي", 4, "التسارع والسقوط الحر", "معادالت الحركة بتسارع ثابت وتسارع الجاذبية األرضية"),
        Lesson("p_1_5", SubjectType.PHYSICS.id, "phys_sec1", "فيزياء أولى ثانوي", 5, "القوى والوزن وقوانين نيوتن", "قانون نيوتن األول والثاني والثالث، والوزن الحقيقي والظاهري"),
        Lesson("p_1_6", SubjectType.PHYSICS.id, "phys_sec1", "فيزياء أولى ثانوي", 6, "المتجهات واالحتكاك والحركة المائلة", "تحليل القوى، االحتكاك السكوني والحركي، والحركة على مستوى مائل"),
        Lesson("p_1_7", SubjectType.PHYSICS.id, "phys_sec1", "فيزياء أولى ثانوي", 7, "المقذوف والحركة الدائرية", "حركة المقذوفات بزاوية، التسارع المركزي، والقوة المركزية"),

        // === فيزياء ثاني ثانوي (6 دروس) ===
        Lesson("p_2_1", SubjectType.PHYSICS.id, "phys_sec2", "فيزياء ثاني ثانوي", 8, "الجاذبية", "قوانين كبلر لحركة الكواكب، وقانون الجذب الكوني لنيوتن"),
        Lesson("p_2_2", SubjectType.PHYSICS.id, "phys_sec2", "فيزياء ثاني ثانوي", 9, "الحركة الدورانية", "اإلزاحة والسرعة والتسارع الزاوي، والعزم وذراع القوة"),
        Lesson("p_2_3", SubjectType.PHYSICS.id, "phys_sec2", "فيزياء ثاني ثانوي", 10, "الاتزان والدفع والزخم", "شروط االتزان الميكانيكي، الدفع، وحفظ الزخم والتصادمات"),
        Lesson("p_2_4", SubjectType.PHYSICS.id, "phys_sec2", "فيزياء ثاني ثانوي", 11, "الشغل والطاقة", "حساب الشغل، نظرية الشغل والطاقة، وطاقة الوضع والحركة"),
        Lesson("p_2_5", SubjectType.PHYSICS.id, "phys_sec2", "فيزياء ثاني ثانوي", 12, "القدرة واآلالت", "حساب القدرة بالواط والحصان، الفائدة الميكانيكية والكفاءة"),
        Lesson("p_2_6", SubjectType.PHYSICS.id, "phys_sec2", "فيزياء ثاني ثانوي", 13, "الحرارة والديناميكا الحرارية", "مقاييس الحرارة، الحرارة النوعية، وقوانين الديناميكا الحرارية"),

        // === كيمياء 1 (5 دروس) ===
        Lesson("c_1_1", SubjectType.CHEMISTRY.id, "chem_1", "كيمياء 1", 1, "مقدمة في علم الكيمياء", "فروع الكيمياء، طبقة األوزون ومركبات CFCs، والطريقة العلمية"),
        Lesson("c_1_2", SubjectType.CHEMISTRY.id, "chem_1", "كيمياء 1", 2, "الخواص والتغيرات والمخاليط", "الخواص الفيزيائية والكيميائية، أنواع المخاليط، وطرق الفصل"),
        Lesson("c_1_3", SubjectType.CHEMISTRY.id, "chem_1", "كيمياء 1", 3, "تركيب الذرة", "النموذج الذري، العدد الذري والكتلي، والنظائر المشعة"),
        Lesson("c_1_4", SubjectType.CHEMISTRY.id, "chem_1", "كيمياء 1", 4, "العنصر والمركب والتفاعالت الكيميائية", "قوانين النسب الثابتة والمتضاعفة، ووزن المعادالت وتصنيف التفاعالت"),
        Lesson("c_1_5", SubjectType.CHEMISTRY.id, "chem_1", "كيمياء 1", 5, "الحسابات الكيميائية", "المول، عدد أفوجادرو، الكتلة المولية، والصيغة األولية والجزيئية"),

        // === كيمياء 2 (8 دروس) ===
        Lesson("c_2_1", SubjectType.CHEMISTRY.id, "chem_2", "كيمياء 2", 6, "الضوء والكم ومستويات الذرة", "الطيف الكهرومغناطيسي، نظرية الكم، ونموذج بور للذرة"),
        Lesson("c_2_2", SubjectType.CHEMISTRY.id, "chem_2", "كيمياء 2", 7, "التوزيع اإللكتروني", "مبدأ أوفباو، قاعدة هوند، واستثناءات التوزيع اإللكتروني"),
        Lesson("c_2_3", SubjectType.CHEMISTRY.id, "chem_2", "كيمياء 2", 8, "الجدول الدوري الحديث", "تدرج المجموعات والدورات وتصنيف الفلزات والالفلزات"),
        Lesson("c_2_4", SubjectType.CHEMISTRY.id, "chem_2", "كيمياء 2", 9, "تصنيف العناصر وتدرج خواصها", "نصف القطر الذري، طاقة التأين، والكهروسالبية"),
        Lesson("c_2_5", SubjectType.CHEMISTRY.id, "chem_2", "كيمياء 2", 10, "الروابط والمركبات األيونية", "تكوين األيونات، الرابطة األيونية، وطاقة الشبكة البلورية"),
        Lesson("c_2_6", SubjectType.CHEMISTRY.id, "chem_2", "كيمياء 2", 11, "الرابطة الفلزية والتساهمية", "بحر اإللكترونات، روابط سيجما وباي، وتسمية الجزيئات"),
        Lesson("c_2_7", SubjectType.CHEMISTRY.id, "chem_2", "كيمياء 2", 12, "تراكيب لويس وأشكال الجزيئات", "نظرية VSEPR، والتهجين وأشكال الجزيئات الفراغية"),
        Lesson("c_2_8", SubjectType.CHEMISTRY.id, "chem_2", "كيمياء 2", 13, "الكهروسالبية والقوى بين الجزيئات", "القطبية، قوى التشتت لندن، والقوى ثنائية القطب والهيدروجينية"),

        // === كيمياء 3 (6 دروس) ===
        Lesson("c_3_1", SubjectType.CHEMISTRY.id, "chem_3", "كيمياء 3", 14, "المادة الغازية", "نظرية الحركة الجزيئية، قانون جراهام، وقانون دالتون للضغوط"),
        Lesson("c_3_2", SubjectType.CHEMISTRY.id, "chem_3", "كيمياء 3", 15, "المواد السائلة والصلبة", "اللزوجة، التوتر السطحي، والخاصية الشعرية والمواد الصلبة"),
        Lesson("c_3_3", SubjectType.CHEMISTRY.id, "chem_3", "كيمياء 3", 16, "تغيرات الحالة الفيزيائية", "مخطط الحالة الفيزيائية، النقطة الثالثية والنقطة الحرجة"),
        Lesson("c_3_4", SubjectType.CHEMISTRY.id, "chem_3", "كيمياء 3", 17, "الطاقة والكيمياء الحرارية", "المحتوى الحراري، التفاعالت الطاردة والماصة، وقانون هس"),
        Lesson("c_3_5", SubjectType.CHEMISTRY.id, "chem_3", "كيمياء 3", 18, "سرعة التفاعالت الكيميائية", "نظرية التصادم، طاقة التنشيط، وقوانين ورتب سرعة التفاعل"),
        Lesson("c_3_6", SubjectType.CHEMISTRY.id, "chem_3", "كيمياء 3", 19, "الاتزان الكيميائي", "تعبير ثابت االتزان، مبدأ لوتشاتلييه، والعوامل المؤثرة"),

        // === كيمياء 4 (7 دروس) ===
        Lesson("c_4_1", SubjectType.CHEMISTRY.id, "chem_4", "كيمياء 4", 20, "الهيدروكربونات", "األلكانات واأللكينات واأللكاينات وتسميتها حسب IUPAC"),
        Lesson("c_4_2", SubjectType.CHEMISTRY.id, "chem_4", "كيمياء 4", 21, "متشكالت الهيدروكربونات", "المتشكالت البنائية والفراغية والمركبات األروماتية"),
        Lesson("c_4_3", SubjectType.CHEMISTRY.id, "chem_4", "كيمياء 4", 22, "مشتقات الهيدروكربونات", "الكحوالت، اإليثرات، األمينات، واأللدهيدات والكيتونات"),
        Lesson("c_4_4", SubjectType.CHEMISTRY.id, "chem_4", "كيمياء 4", 23, "تفاعالت المشتقات", "تفاعالت االستبدال والتكثف والحذف واإلضافة واألكسدة"),
        Lesson("c_4_5", SubjectType.CHEMISTRY.id, "chem_4", "كيمياء 4", 24, "البوليمرات", "المونمرات، تفاعالت البلمرة، وأهم أنواع واستخدامات البوليمرات"),
        Lesson("c_4_6", SubjectType.CHEMISTRY.id, "chem_4", "كيمياء 4", 25, "الكيمياء الحيوية", "البروتينات، الكربوهيدرات، الليبيدات، واألحماض النووية"),
        Lesson("c_4_7", SubjectType.CHEMISTRY.id, "chem_4", "كيمياء 4", 26, "قوانين وحسابات الغازات", "قانون بويل، شارل، جاي لوساك، والغاز المثالي والحسابات"),

        // === أحياء 1 (8 دروس) ===
        Lesson("b_1_1", SubjectType.BIOLOGY.id, "bio_1", "أحياء 1", 1, "دراسة الحياة", "علم األحياء وخصائص الحياة والطريقة العلمية والفرضيات"),
        Lesson("b_1_2", SubjectType.BIOLOGY.id, "bio_1", "أحياء 1", 2, "تنظيم تنوع الحياة", "التسمية الثنائية ومستويات التصنيف والممالك الست"),
        Lesson("b_1_3", SubjectType.BIOLOGY.id, "bio_1", "أحياء 1", 3, "البكتيريا والفيروسات", "البدائيات، البكتيريا وصبغة جرام، وتركيب الفيروسات وتكاثرها"),
        Lesson("b_1_4", SubjectType.BIOLOGY.id, "bio_1", "أحياء 1", 4, "الطالئعيات", "األوليات الشبيهة بالحيوانات، الطحالب، والفطريات الغروية"),
        Lesson("b_1_5", SubjectType.BIOLOGY.id, "bio_1", "أحياء 1", 5, "الفطريات", "خصائص الفطريات، تصنيفها، األشنات، والفطريات الجذرية"),
        Lesson("b_1_6", SubjectType.BIOLOGY.id, "bio_1", "أحياء 1", 6, "مدخل إلى الحيوانات", "مستويات بناء الجسم، التناظر، وتجاويف الجسم والالسعات"),
        Lesson("b_1_7", SubjectType.BIOLOGY.id, "bio_1", "أحياء 1", 7, "الديدان والرخويات", "الديدان المفلطحة واألسطوانية والحلقية، وتنوع الرخويات"),
        Lesson("b_1_8", SubjectType.BIOLOGY.id, "bio_1", "أحياء 1", 8, "المفصليات", "خصائص وطوائف المفصليات، والتحول وأجزاء الفم في الحشرات"),

        // === أحياء 2 (11 درس) ===
        Lesson("b_2_1", SubjectType.BIOLOGY.id, "bio_2", "أحياء 2", 9, "شوكيات الجلد والالفقاريات الحبلية", "الجهاز الوعائي المائي، حبليات الرأس والذيل والسهيم"),
        Lesson("b_2_2", SubjectType.BIOLOGY.id, "bio_2", "أحياء 2", 10, "طائفة األسماك", "خصائص األسماك، القشور، الجهاز الدوري، وتصنيف طوائف األسماك"),
        Lesson("b_2_3", SubjectType.BIOLOGY.id, "bio_2", "أحياء 2", 11, "البرمائيات", "التكيف، دورة حياة الضفدع، والفرق بين الضفادع والعالجيم"),
        Lesson("b_2_4", SubjectType.BIOLOGY.id, "bio_2", "أحياء 2", 12, "الزواحف", "البيضة الرهلية، السحالي واألفاعي والسالاحف، وتنظيم الحرارة"),
        Lesson("b_2_5", SubjectType.BIOLOGY.id, "bio_2", "أحياء 2", 13, "الطيور", "تكيفات الطيران، العظام المجوفة، األكياس الهوائية، والمناقير"),
        Lesson("b_2_6", SubjectType.BIOLOGY.id, "bio_2", "أحياء 2", 14, "الثدييات", "الشعر والغدد اللبنية، الثدييات األولية والكيسية والمشيمية"),
        Lesson("b_2_7", SubjectType.BIOLOGY.id, "bio_2", "أحياء 2", 15, "أسئلة المقارنات بين الفقاريات", "حجرات القلب، ثبات الحرارة، واإلخصاب الداخلي والخارجي"),
        Lesson("b_2_8", SubjectType.BIOLOGY.id, "bio_2", "أحياء 2", 16, "النباتات الوعائية والالوعائية", "الحزازيات، السرخسيات، والنباتات معراة ومغطاة البذور"),
        Lesson("b_2_9", SubjectType.BIOLOGY.id, "bio_2", "أحياء 2", 17, "خاليا وأنسجة النباتات", "الخاليا البرنشيمية والكولنشيمية واإلسكلرنشيمية والخشب واللحاء"),
        Lesson("b_2_10", SubjectType.BIOLOGY.id, "bio_2", "أحياء 2", 18, "الهرمونات واستجابة النبات", "األكسينات والجبريلينات واإليثيلين واالنتحاء الضوئي واألرضي"),
        Lesson("b_2_11", SubjectType.BIOLOGY.id, "bio_2", "أحياء 2", 19, "النباتات الزهرية وتكاثرها", "أعضاء الزهرة، التلقيح، اإلخصاب، وتكوين الثمار والبذور"),

        // === أحياء 3 (12 درس) ===
        Lesson("b_3_1", SubjectType.BIOLOGY.id, "bio_3", "أحياء 3", 20, "الجهاز الهيكلي", "الهيكل المحوري والطرفي، أنواع المفاصل، وتكوين العظام"),
        Lesson("b_3_2", SubjectType.BIOLOGY.id, "bio_3", "أحياء 3", 21, "الجهاز العضلي", "العضالت الهيكلية والملساء والقلبية، وانقباض العضالت وATP"),
        Lesson("b_3_3", SubjectType.BIOLOGY.id, "bio_3", "أحياء 3", 22, "الجهاز العصبي", "الخلية العصبية، السيال العصبي، ورد الفعل المنعكس"),
        Lesson("b_3_4", SubjectType.BIOLOGY.id, "bio_3", "أحياء 3", 23, "تنظيم الجهاز العصبي", "المخ والمخيخ وتحت المهاد، والجهاز السمبثاوي والباراسمبثاوي"),
        Lesson("b_3_5", SubjectType.BIOLOGY.id, "bio_3", "أحياء 3", 24, "الجهاز الدوراني", "القلب، األوعية الدموية، فصائل الدم، والعامل الريزيسي Rh"),
        Lesson("b_3_6", SubjectType.BIOLOGY.id, "bio_3", "أحياء 3", 25, "الجهازان التنفسي واإلخراجي", "الحركات التنفسية، تركيب الكلية، النفرون، وتكوين البول"),
        Lesson("b_3_7", SubjectType.BIOLOGY.id, "bio_3", "أحياء 3", 26, "الجهاز الهضمي", "الهضم الميكانيكي والكيميائي، إنزيمات الهضم، واالمتصاص"),
        Lesson("b_3_8", SubjectType.BIOLOGY.id, "bio_3", "أحياء 3", 27, "التغذية", "السعرات الحرارية، الكربوهيدرات والدهون، والفيتامينات واألمالح"),
        Lesson("b_3_9", SubjectType.BIOLOGY.id, "bio_3", "أحياء 3", 28, "جهاز الغدد الصم", "أنواع الهرمونات، التغذية الراجعة السلبية، واألنسولين والجلوكاجون"),
        Lesson("b_3_10", SubjectType.BIOLOGY.id, "bio_3", "أحياء 3", 29, "جهاز التكاثر في اإلنسان", "الجهاز التناسلي الذكري واألنثوي، والهرمونات ودورة الحيض"),
        Lesson("b_3_11", SubjectType.BIOLOGY.id, "bio_3", "أحياء 3", 30, "مراحل نمو الجنين", "اإلخصاب، األغشية الجنينية والمشيمة، ومراحل نمو الجنين"),
        Lesson("b_3_12", SubjectType.BIOLOGY.id, "bio_3", "أحياء 3", 31, "الجهاز المناعي", "المناعة العامة والمتخصصة، الخاليا التائية والبائية، واللقاحات"),

        // === أحياء 4 (9 دروس) ===
        Lesson("b_4_1", SubjectType.BIOLOGY.id, "bio_4", "أحياء 4", 32, "التراكيب الخلوية", "عضيات الخلية النباتية والحيوانية والغشاء البالزمي"),
        Lesson("b_4_2", SubjectType.BIOLOGY.id, "bio_4", "أحياء 4", 33, "كيمياء الخلية", "الكربوهيدرات، الدهون، البروتينات، واألحماض النووية بالخلية"),
        Lesson("b_4_3", SubjectType.BIOLOGY.id, "bio_4", "أحياء 4", 34, "الطاقة الخلوية", "قوانين الديناميكا الحرارية، ومسارات األيض وجزيء ATP"),
        Lesson("b_4_4", SubjectType.BIOLOGY.id, "bio_4", "أحياء 4", 35, "البناء الضوئي والتنفس الخلوي", "التفاعالت الضوئية ودورة كالفن، والتحلل السكري ودورة كربس"),
        Lesson("b_4_5", SubjectType.BIOLOGY.id, "bio_4", "أحياء 4", 36, "التكاثر الخلوي", "دورة الخلية، االنقسام المتساوي، والسرطان وموت الخلية المبرمج"),
        Lesson("b_4_6", SubjectType.BIOLOGY.id, "bio_4", "أحياء 4", 37, "الانقسام المنصف", "مراحل االنقسام المنصف، وتكوين األمشاج والعبور الجيني"),
        Lesson("b_4_7", SubjectType.BIOLOGY.id, "bio_4", "أحياء 4", 38, "الوراثة المندلية", "تجارب مندل، مربع بانيت، والصفات السائدة والمتنحية"),
        Lesson("b_4_8", SubjectType.BIOLOGY.id, "bio_4", "أحياء 4", 39, "الوراثة المعقدة والبشرية", "السيادة غير التامة والمشتركة، الصفات المرتبطة بالجنس ومخطط الساللة"),
        Lesson("b_4_9", SubjectType.BIOLOGY.id, "bio_4", "أحياء 4", 40, "المادة الوراثية", "تضاعف DNA، النسخ والترجمة لـ RNA، والطفرات الجينية"),

        // === علم البيئة (8 دروس) ===
        Lesson("b_eco_1", SubjectType.BIOLOGY.id, "bio_eco", "علم البيئة", 41, "المخلوقات الحية وعالقاتها المتبادلة", "العوامل الحيوية والالحيوية ومستويات التنظيم البيئي والتكافل"),
        Lesson("b_eco_2", SubjectType.BIOLOGY.id, "bio_eco", "علم البيئة", 42, "انتقال الطاقة في النظام البيئي", "السالسل والشبكات الغذائية واألهرامات البيئية"),
        Lesson("b_eco_3", SubjectType.BIOLOGY.id, "bio_eco", "علم البيئة", 43, "تدوير المواد", "دورات الماء والكربون والنيتروجين والفسفور الحيوية"),
        Lesson("b_eco_4", SubjectType.BIOLOGY.id, "bio_eco", "علم البيئة", 44, "المجتمعات والمناطق الحيوية", "التعاقب البيئي األولي والثانوي والمناطق الحيوية البرية"),
        Lesson("b_eco_5", SubjectType.BIOLOGY.id, "bio_eco", "علم البيئة", 45, "األنظمة البيئية المائية", "المياه العذبة، المصبات، واألنظمة البيئية البحرية واللجة"),
        Lesson("b_eco_6", SubjectType.BIOLOGY.id, "bio_eco", "علم البيئة", 46, "علم بيئة الجماعات الحيوية", "كثافة الجماعة وتوزيعها ونماذج النمو والقدرة االستيعابية"),
        Lesson("b_eco_7", SubjectType.BIOLOGY.id, "bio_eco", "علم البيئة", 47, "التنوع الحيوي والمحافظة عليه", "أهمية التنوع الحيوي والمخاطر وطرق االستصالح البيئي"),
        Lesson("b_eco_8", SubjectType.BIOLOGY.id, "bio_eco", "علم البيئة", 48, "سلوك الحيوان", "السلوك الغريزي والمكتسب، سلوكيات الصراع والسيادة والفرمونات")
    )

    // Complete sample question bank directly extracted from the user's uploaded materials
    val quizQuestions = listOf(
        // === BIOLOGY (أحياء وعلم البيئة) Questions ===
        QuizQuestion(
            id = "bq_1",
            lessonId = "b_1_1",
            subjectId = SubjectType.BIOLOGY.id,
            questionText = "قام باحث أحياء بدراسة الهندسة الزراعية لبعض النباتات وإمكانية مقاومتها للحشرات واألمراض، فإن هذا الباحث يعمل على:",
            options = listOf("البحث في األمراض", "حماية البيئة", "تحسين الزراعة", "دراسة األنواع"),
            correctIndex = 2,
            explanation = "تطوير نباتات تقاوم الحشرات واألمراض يعد تطبيقاً لتحسين المحاصيل الزراعية.",
            yearTag = "2024",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "bq_2",
            lessonId = "b_1_1",
            subjectId = SubjectType.BIOLOGY.id,
            questionText = "أول من كتب وصفاً للجدري والحصبة هو العالم:",
            options = listOf("ابن سينا", "ابن البيطار", "أبو بكر الرازي", "تشارلز درو"),
            correctIndex = 2,
            explanation = "أبو بكر الرازي هو أول من وصف الجدري والحصبة بدقة وميز بينهما.",
            yearTag = "2021",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "bq_3",
            lessonId = "b_1_1",
            subjectId = SubjectType.BIOLOGY.id,
            questionText = "تنظيم الظروف الداخلية للفرد من أجل الحفاظ على حياته يُطلق عليه:",
            options = listOf("االتزان الداخلي", "النمو", "التكيف", "التأقلم"),
            correctIndex = 0,
            explanation = "االتزان الداخلي (Homeostasis) هو الحفاظ على ثبات البيئة الداخلية للكائن الحي.",
            yearTag = "2024",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "bq_4",
            lessonId = "b_1_2",
            subjectId = SubjectType.BIOLOGY.id,
            questionText = "ما االسم العلمي الصحيح للبرتقال حسب نظام لينيوس للتسمية الثنائية؟",
            options = listOf("Cirtus Sinensis", "cirtus sinensis", "Cirtus sinensis", "cirtus Sinensis"),
            correctIndex = 2,
            explanation = "يكتب اسم الجنس بحرف كبير (Capital) بينما اسم النوع يبدأ بحرف صغير (Small).",
            yearTag = "مبكر 2025",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "bq_5",
            lessonId = "b_1_2",
            subjectId = SubjectType.BIOLOGY.id,
            questionText = "عندما تنظم مستويات التصنيف الثمانية من األكبر إلى األصغر، فإن المصنف الذي يمثل المستوى الثالث هو:",
            options = listOf("الطائفة", "الشعبة", "فوق مملكة", "المملكة"),
            correctIndex = 1,
            explanation = "الترتيب: فوق مملكة -> مملكة -> شعبة -> طائفة -> رتبة -> فصيلة -> جنس -> نوع.",
            yearTag = "2025",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "bq_6",
            lessonId = "b_1_3",
            subjectId = SubjectType.BIOLOGY.id,
            questionText = "تركيب خلوي يحمي البكتيريا من أثر المضادات الحيوية والجفاف:",
            options = listOf("البالزميد", "األسواط", "الغشاء البالزمي", "المحفظة"),
            correctIndex = 3,
            explanation = "محفظة البكتيريا توفر طبقة حماية عازلة ضد المضادات الحيوية والظروف القاسية.",
            yearTag = "2024",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "bq_7",
            lessonId = "b_1_4",
            subjectId = SubjectType.BIOLOGY.id,
            questionText = "الطفيل المسبب لمرض النوم األفريقي هو:",
            options = listOf("البالزموديوم", "التريبانوسوما", "األنوفيلس", "ذبابة التسي تسي"),
            correctIndex = 1,
            explanation = "التريبانوسوما (Trypanosoma) هو الطفيل المسبب لمرض النوم وتنقلها ذبابة التسي تسي.",
            yearTag = "2025",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "bq_8",
            lessonId = "b_1_5",
            subjectId = SubjectType.BIOLOGY.id,
            questionText = "المادة عديدة التسكر التي يتكون منها الجدار الخلوي للفطريات هي:",
            options = listOf("السليلوز", "الكايتين", "اللجنين", "السيوبرين"),
            correctIndex = 1,
            explanation = "الكايتين هو المكون الرئيسي لجدار الفطريات بينما السليلوز هو جدار النباتات.",
            yearTag = "2021",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "bq_9",
            lessonId = "b_3_5",
            subjectId = SubjectType.BIOLOGY.id,
            questionText = "أي الحجرات تستقبل الدم المؤكسج القادم من الرئة في قلب اإلنسان؟",
            options = listOf("األذين األيمن", "البطين األيمن", "األذين األيسر", "البطين األيسر"),
            correctIndex = 2,
            explanation = "يستقبل األذين األيسر الدم المؤكسج القادم من األوردة الرئوية.",
            yearTag = "2024",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "bq_10",
            lessonId = "b_eco_1",
            subjectId = SubjectType.BIOLOGY.id,
            questionText = "العالقة بين السمكة المهرجة وشقائق النعمان تمثل عالقة:",
            options = listOf("تنافس", "تقايض (تبادل منفعة)", "افتراس", "تطفل"),
            correctIndex = 1,
            explanation = "تقايض لأن كالهما يستفيد: الحماية والتغذية.",
            yearTag = "2021",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),

        // === MATHEMATICS (الرياضيات) Questions ===
        QuizQuestion(
            id = "mq_1",
            lessonId = "m_1_1",
            subjectId = SubjectType.MATH.id,
            questionText = "أي التالي ناتجه عدد فردي دائماً؟",
            options = listOf("ضرب عدد زوجي بعدد فردي", "تربيع عدد فردي", "تكعيب عدد زوجي", "ضرب عدد زوجي بعدد زوجي"),
            correctIndex = 1,
            explanation = "مربع أي عدد فردي هو عدد فردي (مثال: 3² = 9، 5² = 25).",
            yearTag = "2025",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "mq_2",
            lessonId = "m_1_1",
            subjectId = SubjectType.MATH.id,
            questionText = "أي التالي يُعد مثالاً مضاداً للتخمين «إذا كان العدد أولياً فإنه يكون فردياً»؟",
            options = listOf("11", "5", "3", "2"),
            correctIndex = 3,
            explanation = "العدد 2 هو عدد أولي لكنه زوجي وليس فردياً، فهو المثال المضاد الصريح.",
            yearTag = "2025",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "mq_3",
            lessonId = "m_1_3",
            subjectId = SubjectType.MATH.id,
            questionText = "ميل المستقيم الذي معادلته y - 3 = 2(x - 2) يساوي:",
            options = listOf("2/3", "3/2", "2", "-2"),
            correctIndex = 2,
            explanation = "بصيغة الميل ونقطة y - y₁ = m(x - x₁)، الميل m = 2.",
            yearTag = "2024",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "mq_4",
            lessonId = "m_1_4",
            subjectId = SubjectType.MATH.id,
            questionText = "في مثلث قائم الزاوية ومتطابق الضلعين، فإن قياس أي من زاويتيه الحادتين يساوي:",
            options = listOf("60°", "45°", "30°", "20°"),
            correctIndex = 1,
            explanation = "(180° - 90°) / 2 = 45°.",
            yearTag = "2020",
            sectionType = "القسم الثاني - أسئلة النجمتين"
        ),
        QuizQuestion(
            id = "mq_5",
            lessonId = "m_1_5",
            subjectId = SubjectType.MATH.id,
            questionText = "مجموع قياسات الزوايا الداخلية لمضلع سداسي منتظم يساوي:",
            options = listOf("540°", "720°", "900°", "1080°"),
            correctIndex = 1,
            explanation = "القانون: (n - 2) × 180° = (6 - 2) × 180° = 4 × 180° = 720°.",
            yearTag = "2025",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "mq_6",
            lessonId = "m_2_4",
            subjectId = SubjectType.MATH.id,
            questionText = "قيمة محددة الدرجة الثانية |[2, 1], [-3, 1]| تساوي:",
            options = listOf("5", "6", "7", "8"),
            correctIndex = 0,
            explanation = "2(1) - (1)(-3) = 2 + 3 = 5.",
            yearTag = "2024",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "mq_7",
            lessonId = "m_2_5",
            subjectId = SubjectType.MATH.id,
            questionText = "قيمة المقدار i³⁰ تساوي:",
            options = listOf("-i", "i", "-1", "1"),
            correctIndex = 2,
            explanation = "30 ÷ 4 = 7 والباقي 2، إذن i³⁰ = i² = -1.",
            yearTag = "2025",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "mq_8",
            lessonId = "m_2_10",
            subjectId = SubjectType.MATH.id,
            questionText = "أساس المتتابعة الحسابية: 3, 12, 21, 30 هو:",
            options = listOf("2", "5", "6", "9"),
            correctIndex = 3,
            explanation = "d = 12 - 3 = 9.",
            yearTag = "2023",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),

        // === PHYSICS (الفيزياء) Questions ===
        QuizQuestion(
            id = "pq_1",
            lessonId = "p_1_2",
            subjectId = SubjectType.PHYSICS.id,
            questionText = "أي الكميات التالية كمية متجهة وليست قياسية؟",
            options = listOf("الزمن", "المسافة", "الكتلة", "التسارع"),
            correctIndex = 3,
            explanation = "التسارع كمية متجهة تحدد بالمقدار واالتجاه، بينما البقية كميات قياسية.",
            yearTag = "2025",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "pq_2",
            lessonId = "p_1_4",
            subjectId = SubjectType.PHYSICS.id,
            questionText = "سقط حجر من أعلى مبنى ووصل إلى األرض بعد 10 ثوان، فإن سرعته لحظة اصطدامه باألرض تساوي (باعتبار g = 9.8 m/s²):",
            options = listOf("9.8 m/s", "98 m/s", "980 m/s", "9800 m/s"),
            correctIndex = 1,
            explanation = "vf = vi + gt = 0 + 9.8 × 10 = 98 m/s.",
            yearTag = "2023",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "pq_3",
            lessonId = "p_1_5",
            subjectId = SubjectType.PHYSICS.id,
            questionText = "إذا كان وزن الجسم على األرض 980 N فإن كتلته تساوي (g = 9.8 m/s²):",
            options = listOf("980 kg", "100 kg", "10 kg", "98 kg"),
            correctIndex = 1,
            explanation = "m = Fg / g = 980 / 9.8 = 100 kg.",
            yearTag = "2020",
            sectionType = "القسم الثاني - أسئلة النجمتين"
        ),
        QuizQuestion(
            id = "pq_4",
            lessonId = "p_2_3",
            subjectId = SubjectType.PHYSICS.id,
            questionText = "حاصل ضرب القوة المؤثرة في جسم في زمن تأثير هذه القوة يمثل:",
            options = listOf("الزخم", "التسارع", "الحركة الدورانية", "الدفع"),
            correctIndex = 3,
            explanation = "الدفع = القوة × زمن التأثير (Impulse = F · Δt).",
            yearTag = "2021",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "pq_5",
            lessonId = "p_2_4",
            subjectId = SubjectType.PHYSICS.id,
            questionText = "المساحة المحصورة تحت منحنى (القوة - اإلزاحة) تمثل فيزيائياً:",
            options = listOf("القوة", "الشغل", "القدرة", "الزخم"),
            correctIndex = 1,
            explanation = "المساحة تحت منحنى (القوة مقابل اإلزاحة) تمثل الشغل المبذول (Work = F · d).",
            yearTag = "2025",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "pq_6",
            lessonId = "p_2_6",
            subjectId = SubjectType.PHYSICS.id,
            questionText = "درجة الصفر المطلق في مقياس كلفن تعادل على مقياس سيليزيوس:",
            options = listOf("373°C", "-273°C", "-32°C", "0°C"),
            correctIndex = 1,
            explanation = "0 K = -273.15 °C.",
            yearTag = "مبكر 2025",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),

        // === CHEMISTRY (الكيمياء) Questions ===
        QuizQuestion(
            id = "cq_1",
            lessonId = "c_1_1",
            subjectId = SubjectType.CHEMISTRY.id,
            questionText = "فرع الكيمياء الذي يهتم بدراسة المركبات التي تحتوي على الكربون هو:",
            options = listOf("الكيمياء التحليلية", "الكيمياء العضوية", "الكيمياء الذرية", "الكيمياء الفيزيائية"),
            correctIndex = 1,
            explanation = "الكيمياء العضوية هي العلم المختص بمركبات عنصر الكربون.",
            yearTag = "2024",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "cq_2",
            lessonId = "c_1_1",
            subjectId = SubjectType.CHEMISTRY.id,
            questionText = "عدد جزيئات غاز األوزون O₃ الناتجة عن تفكك 12 ذرة أكسجين O هو:",
            options = listOf("3", "4", "2", "6"),
            correctIndex = 1,
            explanation = "كل جزيء أوزون يحتاج 3 ذرات أكسجين: 12 ÷ 3 = 4 جزيئات.",
            yearTag = "2021",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "cq_3",
            lessonId = "c_1_5",
            subjectId = SubjectType.CHEMISTRY.id,
            questionText = "عدد الموالت الموجودة في 36g من الماء H₂O (الكتل: H=1, O=16) يساوي:",
            options = listOf("0.5 mol", "2 mol", "18 mol", "38 mol"),
            correctIndex = 1,
            explanation = "الكتلة المولية للماء = (2×1) + 16 = 18 g/mol. عدد الموالت = 36 ÷ 18 = 2 mol.",
            yearTag = "2025",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "cq_4",
            lessonId = "c_2_4",
            subjectId = SubjectType.CHEMISTRY.id,
            questionText = "أعلى العناصر كهروسالبية في الجدول الدوري الحديث هو عنصر:",
            options = listOf("الكلور Cl", "الفلور F", "السيزيوم Cs", "الفرنسيوم Fr"),
            correctIndex = 1,
            explanation = "الفلور F هو أعلى العناصر في السالبية الكهربية بقيمة 3.98 على مقياس باولنج.",
            yearTag = "2024",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "cq_5",
            lessonId = "c_3_6",
            subjectId = SubjectType.CHEMISTRY.id,
            questionText = "العامل الوحيد الذي يغير من قيمة ثابت االتزان Keq هو:",
            options = listOf("الضغط والحجم", "التركيز", "العامل المحفز", "درجة الحرارة"),
            correctIndex = 3,
            explanation = "تغيير درجة الحرارة هو العامل الوحيد الذي يؤثر على القيمة العددية لثابت االتزان.",
            yearTag = "2021",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        ),
        QuizQuestion(
            id = "cq_6",
            lessonId = "c_4_1",
            subjectId = SubjectType.CHEMISTRY.id,
            questionText = "اسم المركب CH₃-CH₂-CH₂-CH₂-CH₃ حسب قواعد نظام IUPAC هو:",
            options = listOf("بنتان", "هكسان", "بنتين", "هكسين"),
            correctIndex = 0,
            explanation = "ألكان خطي يحتوي على 5 ذرات كربون مشبعة -> بنتان (Pentane).",
            yearTag = "2024",
            sectionType = "القسم األول - أسئلة الـ 3 نجوم"
        )
    )

    // Exam targets default list (Period 1: Nov 8, 2026, Period 2: Dec 15, 2026)
    val defaultExamTargets: List<ExamTargetEntity>
        get() {
            val calP1 = Calendar.getInstance().apply {
                set(2026, Calendar.NOVEMBER, 8, 8, 0, 0)
            }
            val calP2 = Calendar.getInstance().apply {
                set(2026, Calendar.DECEMBER, 15, 8, 0, 0)
            }
            return listOf(
                ExamTargetEntity(
                    id = "period_1",
                    title = "الفترة األولى",
                    subtitle = "8 نوفمبر 2026",
                    targetTimestamp = calP1.timeInMillis,
                    isSelected = true,
                    notes = "اختبار الفترة األولى للتحصيلي المبكر والقبول بجامعة الملك فهد للبترول والمعادن"
                ),
                ExamTargetEntity(
                    id = "period_2",
                    title = "الفترة الثانية",
                    subtitle = "15 ديسمبر 2026",
                    targetTimestamp = calP2.timeInMillis,
                    isSelected = false,
                    notes = "اختبار الفترة الثانية لجامعة الملك فهد للبترول والمعادن"
                )
            )
        }

    // Default daily study tasks for 24-day plan matching Screenshot 20
    val defaultStudyTasks = listOf(
        StudyTaskEntity(
            dayNumber = 1,
            title = "مشاهدة شرح التأسيس لدرس (الاحتماالت)",
            subjectId = SubjectType.MATH.id,
            lessonId = "m_2_12",
            isCompleted = false,
            dateLabel = "28 أغسطس"
        ),
        StudyTaskEntity(
            dayNumber = 1,
            title = "حل اختبار القسم األول لدرس (الاحتماالت)",
            subjectId = SubjectType.MATH.id,
            lessonId = "m_2_12",
            isCompleted = false,
            dateLabel = "28 أغسطس"
        ),
        StudyTaskEntity(
            dayNumber = 1,
            title = "مشاهدة شرح التأسيس لدرس (حسابات المثلثات)",
            subjectId = SubjectType.MATH.id,
            lessonId = "m_2_13",
            isCompleted = false,
            dateLabel = "28 أغسطس"
        ),
        StudyTaskEntity(
            dayNumber = 1,
            title = "حل اختبار القسم األول لدرس (حسابات المثلثات)",
            subjectId = SubjectType.MATH.id,
            lessonId = "m_2_13",
            isCompleted = false,
            dateLabel = "28 أغسطس"
        ),
        StudyTaskEntity(
            dayNumber = 2,
            title = "مراجعة سريعة لمنهج رياضيات 2 ث الذي أنهيته كامالً (التأسيس واألخطاء والمالحظات)",
            subjectId = SubjectType.MATH.id,
            lessonId = "m_2_1",
            isCompleted = false,
            dateLabel = "29 أغسطس"
        ),
        StudyTaskEntity(
            dayNumber = 2,
            title = "مشاهدة شرح درس (أساسيات ومدخل الفيزياء)",
            subjectId = SubjectType.PHYSICS.id,
            lessonId = "p_1_1",
            isCompleted = false,
            dateLabel = "29 أغسطس"
        ),
        StudyTaskEntity(
            dayNumber = 3,
            title = "حل اختبار تجميعات درس (اإلزاحة والسرعة والتسارع)",
            subjectId = SubjectType.PHYSICS.id,
            lessonId = "p_1_3",
            isCompleted = false,
            dateLabel = "30 أغسطس"
        ),
        StudyTaskEntity(
            dayNumber = 3,
            title = "مذاكرة درس (الخواص والتغيرات والمخاليط - كيمياء)",
            subjectId = SubjectType.CHEMISTRY.id,
            lessonId = "c_1_2",
            isCompleted = false,
            dateLabel = "30 أغسطس"
        ),
        StudyTaskEntity(
            dayNumber = 4,
            title = "حل اختبار (تركيب الذرة والحسابات الكيميائية)",
            subjectId = SubjectType.CHEMISTRY.id,
            lessonId = "c_1_3",
            isCompleted = false,
            dateLabel = "31 أغسطس"
        ),
        StudyTaskEntity(
            dayNumber = 4,
            title = "مذاكرة وحل تجميعات درس (دراسة الحياة وتنظيم التنوع - أحياء)",
            subjectId = SubjectType.BIOLOGY.id,
            lessonId = "b_1_1",
            isCompleted = false,
            dateLabel = "31 أغسطس"
        )
    )
}
