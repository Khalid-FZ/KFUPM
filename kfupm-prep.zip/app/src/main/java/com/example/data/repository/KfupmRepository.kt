package com.example.data.repository

import com.example.data.local.AppDao
import com.example.data.local.CurriculumDataSource
import com.example.data.model.ExamTargetEntity
import com.example.data.model.GradeSection
import com.example.data.model.Lesson
import com.example.data.model.LessonProgressEntity
import com.example.data.model.QuizQuestion
import com.example.data.model.QuizResultEntity
import com.example.data.model.StudyTaskEntity
import com.example.data.model.SubjectType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class KfupmRepository(private val appDao: AppDao) {

    val lessonProgressFlow: Flow<List<LessonProgressEntity>> = appDao.getAllLessonProgress()
    val quizResultsFlow: Flow<List<QuizResultEntity>> = appDao.getAllQuizResults()
    val studyTasksFlow: Flow<List<StudyTaskEntity>> = appDao.getAllTasks()
    val examTargetsFlow: Flow<List<ExamTargetEntity>> = appDao.getAllExamTargets()

    suspend fun initializeDefaultsIfNeeded() {
        val currentTargets = appDao.getAllExamTargets().first()
        if (currentTargets.isEmpty()) {
            appDao.insertExamTargets(CurriculumDataSource.defaultExamTargets)
        }
        val currentTasks = appDao.getAllTasks().first()
        if (currentTasks.isEmpty()) {
            appDao.insertTasks(CurriculumDataSource.defaultStudyTasks)
        }
    }

    fun getAllSubjects(): List<SubjectType> = CurriculumDataSource.subjects

    fun getGradeSectionsForSubject(subjectId: String): List<GradeSection> {
        return CurriculumDataSource.gradeSections.filter { it.subjectId == subjectId }
    }

    fun getLessonsForGradeSection(gradeSectionId: String): List<Lesson> {
        return CurriculumDataSource.allLessons.filter { it.gradeSectionId == gradeSectionId }
    }

    fun getLessonById(lessonId: String): Lesson? {
        return CurriculumDataSource.allLessons.find { it.id == lessonId }
    }

    fun getQuestionsForLesson(lessonId: String): List<QuizQuestion> {
        val specific = CurriculumDataSource.quizQuestions.filter { it.lessonId == lessonId }
        if (specific.isNotEmpty()) return specific
        // If lesson doesn't have custom questions yet, provide relevant subject questions
        val lesson = getLessonById(lessonId)
        val subjectQuestions = if (lesson != null) {
            CurriculumDataSource.quizQuestions.filter { it.subjectId == lesson.subjectId }
        } else {
            CurriculumDataSource.quizQuestions
        }
        return if (subjectQuestions.isNotEmpty()) subjectQuestions else CurriculumDataSource.quizQuestions
    }

    fun getQuestionsForSubject(subjectId: String): List<QuizQuestion> {
        return CurriculumDataSource.quizQuestions.filter { it.subjectId == subjectId }
    }

    fun getAllQuestions(): List<QuizQuestion> = CurriculumDataSource.quizQuestions

    suspend fun toggleLessonCompletion(lessonId: String, subjectId: String) {
        val current = appDao.getLessonProgress(lessonId)
        val newStatus = !(current?.isCompleted ?: false)
        val updated = LessonProgressEntity(
            lessonId = lessonId,
            subjectId = subjectId,
            isCompleted = newStatus,
            completedAt = if (newStatus) System.currentTimeMillis() else null,
            notes = current?.notes ?: "",
            confidence = current?.confidence ?: 3
        )
        appDao.insertOrUpdateProgress(updated)
    }

    suspend fun saveLessonNotes(lessonId: String, subjectId: String, notes: String, confidence: Int) {
        val current = appDao.getLessonProgress(lessonId)
        val updated = (current ?: LessonProgressEntity(lessonId = lessonId, subjectId = subjectId)).copy(
            notes = notes,
            confidence = confidence
        )
        appDao.insertOrUpdateProgress(updated)
    }

    suspend fun saveQuizResult(result: QuizResultEntity): Long {
        return appDao.insertQuizResult(result)
    }

    suspend fun setTaskCompleted(taskId: Long, isCompleted: Boolean) {
        appDao.setTaskCompleted(taskId, isCompleted)
    }

    suspend fun selectExamTarget(targetId: String) {
        appDao.selectExamTarget(targetId)
    }
}
