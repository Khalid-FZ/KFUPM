package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.CurriculumDataSource
import com.example.data.model.ExamTargetEntity
import com.example.data.model.Lesson
import com.example.data.model.LessonProgressEntity
import com.example.data.model.QuizQuestion
import com.example.data.model.QuizResultEntity
import com.example.data.model.StudyTaskEntity
import com.example.data.model.SubjectType
import com.example.data.repository.KfupmRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CountdownTime(
    val months: Long,
    val days: Long,
    val hours: Long,
    val minutes: Long,
    val seconds: Long
)

data class SubjectProgress(
    val subject: SubjectType,
    val totalLessons: Int,
    val completedLessons: Int,
    val percentage: Int
)

data class ActiveQuizState(
    val title: String,
    val lessonId: String?,
    val subjectId: String,
    val questions: List<QuizQuestion>,
    val currentIndex: Int = 0,
    val selectedOptionIndex: Int? = null,
    val userAnswers: Map<Int, Int> = emptyMap(), // questionIndex -> selectedOptionIndex
    val isSubmitted: Boolean = false,
    val score: Int = 0,
    val timeElapsedSeconds: Int = 0,
    val isFinished: Boolean = false
)

class KfupmViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: KfupmRepository = KfupmRepository(
        AppDatabase.getDatabase(application).appDao()
    )

    // Current navigation tab
    private val _currentTab = MutableStateFlow("home")
    val currentTab: StateFlow<String> = _currentTab.asStateFlow()

    // Selected subject in curriculum tab
    private val _selectedSubject = MutableStateFlow(SubjectType.MATH)
    val selectedSubject: StateFlow<SubjectType> = _selectedSubject.asStateFlow()

    // Search query for lessons
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Active Quiz session
    private val _activeQuiz = MutableStateFlow<ActiveQuizState?>(null)
    val activeQuiz: StateFlow<ActiveQuizState?> = _activeQuiz.asStateFlow()

    // Dark mode state
    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    // Target countdown calculations
    private val _currentTimeMillis = MutableStateFlow(System.currentTimeMillis())

    // Database flows
    val lessonProgress = repository.lessonProgressFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val quizResults = repository.quizResultsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val studyTasks = repository.studyTasksFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val examTargets = repository.examTargetsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Active Exam Target
    val activeExamTarget: StateFlow<ExamTargetEntity?> = examTargets.combine(_currentTimeMillis) { targets, _ ->
        targets.find { it.isSelected } ?: targets.firstOrNull()
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    // Live remaining countdown
    val countdownState: StateFlow<CountdownTime> = combine(activeExamTarget, _currentTimeMillis) { target, current ->
        if (target == null) {
            CountdownTime(1, 10, 2, 8, 44)
        } else {
            val diff = target.targetTimestamp - current
            if (diff <= 0) {
                CountdownTime(0, 0, 0, 0, 0)
            } else {
                val totalSeconds = diff / 1000
                val seconds = totalSeconds % 60
                val totalMinutes = totalSeconds / 60
                val minutes = totalMinutes % 60
                val totalHours = totalMinutes / 60
                val hours = totalHours % 24
                val totalDays = totalHours / 24
                val months = totalDays / 30
                val days = totalDays % 30
                CountdownTime(months, days, hours, minutes, seconds)
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = CountdownTime(1, 10, 2, 8, 44)
    )

    // Subjects progress calculations
    val subjectProgressList: StateFlow<List<SubjectProgress>> = lessonProgress.combine(_currentTimeMillis) { progressList, _ ->
        val completedIds = progressList.filter { it.isCompleted }.map { it.lessonId }.toSet()
        CurriculumDataSource.subjects.map { subject ->
            val total = CurriculumDataSource.allLessons.count { it.subjectId == subject.id }
            val completed = CurriculumDataSource.allLessons.count { it.subjectId == subject.id && it.id in completedIds }
            val percent = if (total > 0) (completed * 100) / total else 0
            SubjectProgress(subject, total, completed, percent)
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Overall progress percentage
    val overallProgressPercent: StateFlow<Int> = lessonProgress.combine(_currentTimeMillis) { progressList, _ ->
        val total = CurriculumDataSource.allLessons.size
        val completed = progressList.count { it.isCompleted }
        if (total > 0) (completed * 100) / total else 0
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 8 // Default start visual matching screenshot
    )

    init {
        viewModelScope.launch {
            repository.initializeDefaultsIfNeeded()
        }
        // Start 1-second countdown ticker
        viewModelScope.launch {
            while (true) {
                delay(1000)
                _currentTimeMillis.value = System.currentTimeMillis()
                // Update quiz timer if active
                _activeQuiz.value?.let { quiz ->
                    if (!quiz.isFinished) {
                        _activeQuiz.value = quiz.copy(timeElapsedSeconds = quiz.timeElapsedSeconds + 1)
                    }
                }
            }
        }
    }

    fun navigateToTab(tab: String) {
        _currentTab.value = tab
    }

    fun selectSubject(subject: SubjectType) {
        _selectedSubject.value = subject
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun toggleLessonCompletion(lessonId: String, subjectId: String) {
        viewModelScope.launch {
            repository.toggleLessonCompletion(lessonId, subjectId)
        }
    }

    fun toggleTask(taskId: Long, currentStatus: Boolean) {
        viewModelScope.launch {
            repository.setTaskCompleted(taskId, !currentStatus)
        }
    }

    fun selectExamPeriod(targetId: String) {
        viewModelScope.launch {
            repository.selectExamTarget(targetId)
        }
    }

    fun startQuizForLesson(lesson: Lesson) {
        val questions = repository.getQuestionsForLesson(lesson.id)
        _activeQuiz.value = ActiveQuizState(
            title = "اختبار: ${lesson.titleAr}",
            lessonId = lesson.id,
            subjectId = lesson.subjectId,
            questions = questions,
            currentIndex = 0,
            selectedOptionIndex = null,
            userAnswers = emptyMap(),
            isSubmitted = false,
            score = 0,
            timeElapsedSeconds = 0,
            isFinished = false
        )
        _currentTab.value = "quiz"
    }

    fun startComprehensiveQuiz(subject: SubjectType) {
        val questions = repository.getQuestionsForSubject(subject.id).shuffled()
        _activeQuiz.value = ActiveQuizState(
            title = "اختبار شامل: ${subject.titleAr}",
            lessonId = null,
            subjectId = subject.id,
            questions = questions,
            currentIndex = 0,
            selectedOptionIndex = null,
            userAnswers = emptyMap(),
            isSubmitted = false,
            score = 0,
            timeElapsedSeconds = 0,
            isFinished = false
        )
        _currentTab.value = "quiz"
    }

    fun startFullKfupmMockExam() {
        val allQuestions = repository.getAllQuestions().shuffled().take(20)
        _activeQuiz.value = ActiveQuizState(
            title = "محاكاة اختبار قبول البترول (KFUPM)",
            lessonId = null,
            subjectId = "all",
            questions = allQuestions,
            currentIndex = 0,
            selectedOptionIndex = null,
            userAnswers = emptyMap(),
            isSubmitted = false,
            score = 0,
            timeElapsedSeconds = 0,
            isFinished = false
        )
        _currentTab.value = "quiz"
    }

    fun selectQuizOption(optionIndex: Int) {
        val current = _activeQuiz.value ?: return
        if (current.isSubmitted) return
        _activeQuiz.value = current.copy(selectedOptionIndex = optionIndex)
    }

    fun submitCurrentQuestion() {
        val current = _activeQuiz.value ?: return
        val selected = current.selectedOptionIndex ?: return
        val currentQ = current.questions[current.currentIndex]
        val isCorrect = selected == currentQ.correctIndex

        val newAnswers = current.userAnswers.toMutableMap()
        newAnswers[current.currentIndex] = selected

        val newScore = if (isCorrect) current.score + 1 else current.score

        _activeQuiz.value = current.copy(
            userAnswers = newAnswers,
            isSubmitted = true,
            score = newScore
        )
    }

    fun nextQuestion() {
        val current = _activeQuiz.value ?: return
        if (current.currentIndex + 1 < current.questions.size) {
            _activeQuiz.value = current.copy(
                currentIndex = current.currentIndex + 1,
                selectedOptionIndex = null,
                isSubmitted = false
            )
        } else {
            // Finish quiz & save results
            finishQuiz()
        }
    }

    fun finishQuiz() {
        val current = _activeQuiz.value ?: return
        val total = current.questions.size
        val scorePercent = if (total > 0) (current.score * 100) / total else 0

        viewModelScope.launch {
            repository.saveQuizResult(
                QuizResultEntity(
                    lessonId = current.lessonId ?: "general",
                    subjectId = current.subjectId,
                    quizTitle = current.title,
                    totalQuestions = total,
                    correctAnswers = current.score,
                    scorePercentage = scorePercent,
                    timeTakenSeconds = current.timeElapsedSeconds
                )
            )
        }

        _activeQuiz.value = current.copy(isFinished = true)
    }

    fun resetQuiz() {
        _activeQuiz.value = null
        _currentTab.value = "home"
    }
}
