package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.QuizHistoryChart
import com.example.ui.components.SubjectMasteryChart
import com.example.ui.viewmodel.KfupmViewModel

@Composable
fun AnalyticsScreen(
    viewModel: KfupmViewModel,
    modifier: Modifier = Modifier
) {
    val overallProgress by viewModel.overallProgressPercent.collectAsState()
    val subjectProgress by viewModel.subjectProgressList.collectAsState()
    val quizResults by viewModel.quizResults.collectAsState()

    val totalTests = quizResults.size
    val totalQuestionsAnswered = quizResults.sumOf { it.totalQuestions }
    val totalCorrect = quizResults.sumOf { it.correctAnswers }
    val overallAccuracy = if (totalQuestionsAnswered > 0) (totalCorrect * 100) / totalQuestionsAnswered else 0

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF0F7645),
            shadowElevation = 3.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "التقدم والتحليالت",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Icon(
                    imageVector = Icons.Default.QueryStats,
                    contentDescription = null,
                    tint = Color(0xFFFBBF24),
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // High-Level KPIs Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    KpiCard(
                        title = "نسبة الجاهزية",
                        value = "$overallProgress%",
                        subtitle = "منهج التحصيلي",
                        color = Color(0xFF0F7645),
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "دقة اإلجابات",
                        value = "$overallAccuracy%",
                        subtitle = "$totalCorrect من $totalQuestionsAnswered سؤال",
                        color = Color(0xFF0284C7),
                        modifier = Modifier.weight(1f)
                    )
                    KpiCard(
                        title = "االختبارات",
                        value = "$totalTests",
                        subtitle = "اختبارات منجزة",
                        color = Color(0xFFD97706),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // KFUPM Entrance Readiness Forecast
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.School,
                                contentDescription = null,
                                tint = Color(0xFF0F7645),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "تقييم الجاهزية الختبار قبول البترول",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        val readinessStage = when {
                            overallProgress >= 75 && overallAccuracy >= 80 -> "مستوى تنافسي متقدم جداً - مرشح بقوة للقبول المبكر"
                            overallProgress >= 40 || overallAccuracy >= 65 -> "مستوى جيد مع استمرار تصاعدي - استمر في تغطية الدروس المتبقية"
                            else -> "في مرحلة التأسيس األولى - ركّز على إنجاز مهام الخطة اليومية"
                        }

                        Text(
                            text = readinessStage,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF0F7645),
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "نصيحة المنصة: اختبارات جامعة الملك فهد للبترول والمعادن تركز بقوة على مفاهيم الرياضيات والفيزياء والكيمياء. احرص على إنهاء تجميعات القسم األول (3 نجوم) أوالً ثم مراجعة القسم الثاني.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 17.sp
                        )
                    }
                }
            }

            // Subject Mastery Progress Chart
            item {
                SubjectMasteryChart(progressList = subjectProgress)
            }

            // Quiz History
            item {
                QuizHistoryChart(results = quizResults)
            }
        }
    }
}

@Composable
private fun KpiCard(
    title: String,
    value: String,
    subtitle: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
    }
}
