package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette - KFUPM & Saudi Emerald Green Identity
val PrimaryGreen = Color(0xFF0F7645)
val PrimaryGreenDark = Color(0xFF0A5430)
val PrimaryGreenLight = Color(0xFF16A34A)
val SecondaryTeal = Color(0xFF0D9488)
val AccentAmber = Color(0xFFD97706)
val AccentAmberLight = Color(0xFFFBBF24)
val AccentPurple = Color(0xFF7C3AED)
val AccentRose = Color(0xFFE11D48)

val BackgroundLight = Color(0xFFF7FAF8)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEDF6F0)
val OutlineLight = Color(0xFFCBD5E1)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)

// Dark Palette
val PrimaryGreenNight = Color(0xFF34D399)
val SecondaryTealNight = Color(0xFF2DD4BF)
val BackgroundNight = Color(0xFF0F1713)
val SurfaceNight = Color(0xFF16231D)
val SurfaceVariantNight = Color(0xFF1E332A)
val TextPrimaryNight = Color(0xFFF1F5F9)
val TextSecondaryNight = Color(0xFF94A3B8)
